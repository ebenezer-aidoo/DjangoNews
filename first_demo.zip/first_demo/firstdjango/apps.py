from django.apps import AppConfig


class FirstdjangoConfig(AppConfig):
    name = 'firstdjango'
