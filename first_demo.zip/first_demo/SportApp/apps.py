from django.apps import AppConfig


class SportappConfig(AppConfig):
    name = 'SportApp'
